# Публикация Metroris на GitHub Pages

## Что загрузить
Загрузи в корень репозитория все файлы из этой папки:
- `index.html`
- `styles.css`
- `app.js`
- `.nojekyll`

Файл `supabase-setup.sql` нужен для настройки базы Supabase. `README.md` содержит полную инструкцию.

## Пошагово
1. Войди в GitHub и нажми **New repository**.
2. Назови репозиторий `metroris`. Для бесплатного GitHub Pages выбери **Public**.
3. Создай репозиторий.
4. Нажми **Add file → Upload files**, перетащи файлы проекта в корень репозитория и нажми **Commit changes**.
5. Открой **Settings → Pages**.
6. В разделе **Build and deployment** выбери **Deploy from a branch**.
7. Выбери ветку **main** и папку **/(root)**, затем нажми **Save**.
8. Подожди завершения публикации. Адрес будет `https://ТВОЙ-ЛОГИН.github.io/metroris/`.

## Важно: подключи Supabase
До или после публикации открой `app.js` и укажи в начале файла:
- `SUPABASE_URL` — Project URL из Supabase;
- `SUPABASE_ANON_KEY` — anon/public key из Supabase.

Не вставляй `service_role` key. После изменения `app.js` снова загрузи его в репозиторий (или открой файл на GitHub, нажми ✏️ Edit и сохрани изменения).

В Supabase открой **Authentication → URL Configuration** и добавь адрес GitHub Pages в **Site URL** и **Redirect URLs**.

GitHub Pages размещает только статические файлы. Регистрация, база данных, публикации и сообщения работают через подключённый Supabase. Сам сайт не будет полноценно работать с аккаунтами, пока Supabase не настроен.
